package io.chatbotia.domain.common;
public class DomainException extends RuntimeException { public DomainException(String m){super(m);} }
