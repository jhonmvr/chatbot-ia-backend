package io.chatbotia.domain.types; public enum Language { ES, EN, PT }
