package io.chatbotia.domain.types; public enum Direction { IN, OUT }
