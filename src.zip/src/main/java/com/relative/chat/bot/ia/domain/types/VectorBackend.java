package io.chatbotia.domain.types; public enum VectorBackend { PGVECTOR, QDRANT, PINECONE, MILVUS, WEAVIATE, OPENSEARCH }
