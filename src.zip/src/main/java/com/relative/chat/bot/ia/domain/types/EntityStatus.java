package io.chatbotia.domain.types; public enum EntityStatus { ACTIVE, INACTIVE, BLOCKED, DELETED }
