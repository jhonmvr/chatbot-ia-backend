package io.chatbotia.domain.types; public enum QueueStatus { PENDING, SENDING, SENT, FAILED, SCHEDULED, PAUSED, RETRYING, CANCELLED }
