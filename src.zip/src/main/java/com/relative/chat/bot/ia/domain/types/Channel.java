package io.chatbotia.domain.types; public enum Channel { WHATSAPP, SMS, TELEGRAM, WEB, EMAIL }
