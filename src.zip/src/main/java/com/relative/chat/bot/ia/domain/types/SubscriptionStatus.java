package io.chatbotia.domain.types; public enum SubscriptionStatus { ACTIVE, CANCELED, PAST_DUE, IN_TRIAL, PAUSED, EXPIRED }
