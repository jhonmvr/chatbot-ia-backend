package io.chatbotia.domain.types; public enum ConversationStatus { OPEN, CLOSED, ARCHIVED }
